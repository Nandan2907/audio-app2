#include <iostream>

void say_hello(){
    std::cout << "Hello, from ffmpeg_audio_codec!\n";
}
